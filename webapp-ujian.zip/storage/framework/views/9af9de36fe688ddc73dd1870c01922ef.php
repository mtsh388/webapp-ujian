

<?php $__env->startSection('title', 'Detail Hasil Ujian Anak'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
            <div>
                <h4 class="fw-bold mb-1">
                    <span class="text-muted fw-light">Hasil Ujian Anak /</span>
                    Detail Hasil
                </h4>
                <p class="text-muted mb-0">
                    Detail hasil ujian dan pembahasan jawaban anak.
                </p>
            </div>

            <a href="<?php echo e(route('results.children')); ?>" class="btn btn-outline-secondary">
                <i class="bx bx-arrow-back me-1"></i>
                Kembali
            </a>
        </div>

        <div class="row g-4 mb-4">
            <div class="col-md-6">
                <div class="card h-100">
                    <div class="card-header">
                        <h5 class="mb-0">Informasi Siswa</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <small class="text-muted d-block">Nama Siswa</small>
                            <span class="fw-semibold">
                                <?php echo e($attempt->student->full_name ?? '-'); ?>

                            </span>
                        </div>

                        <div class="mb-3">
                            <small class="text-muted d-block">Nomor Siswa</small>
                            <span>
                                <?php echo e($attempt->student->student_number ?? '-'); ?>

                            </span>
                        </div>

                        <div>
                            <small class="text-muted d-block">Kelas</small>
                            <span>
                                <?php echo e($attempt->student->classRoom->name ?? '-'); ?>

                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card h-100">
                    <div class="card-header">
                        <h5 class="mb-0">Informasi Ujian</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <small class="text-muted d-block">Nama Ujian</small>
                            <span class="fw-semibold">
                                <?php echo e($attempt->exam->title ?? $attempt->exam->name ?? '-'); ?>

                            </span>
                        </div>

                        <div class="mb-3">
                            <small class="text-muted d-block">Mulai Ujian</small>
                            <span>
                                <?php echo e($attempt->started_at
                                    ? \Illuminate\Support\Carbon::parse($attempt->started_at)->format('d/m/Y H:i')
                                    : '-'); ?>

                            </span>
                        </div>

                        <div>
                            <small class="text-muted d-block">Selesai Ujian</small>
                            <span>
                                <?php echo e($attempt->submitted_at
                                    ? \Illuminate\Support\Carbon::parse($attempt->submitted_at)->format('d/m/Y H:i')
                                    : '-'); ?>

                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-body">
                <div class="row align-items-center g-3">
                    <div class="col-md-4">
                        <small class="text-muted d-block">Nilai Akhir</small>
                        <h2 class="fw-bold text-primary mb-0">
                            <?php echo e(number_format((float) ($attempt->score ?? 0), 2, ',', '.')); ?>

                        </h2>
                    </div>

                    <div class="col-md-4">
                        <small class="text-muted d-block">Status Ujian</small>
                        <?php if($attempt->submitted_at): ?>
                            <span class="badge bg-label-success">Selesai</span>
                        <?php else: ?>
                            <span class="badge bg-label-warning">Belum Selesai</span>
                        <?php endif; ?>
                    </div>

                    <div class="col-md-4">
                        <small class="text-muted d-block">Jumlah Soal Dijawab</small>
                        <h5 class="mb-0 mt-1">
                            <?php echo e($attempt->answers->count()); ?>

                        </h5>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h5 class="mb-1">Detail Jawaban dan Pembahasan</h5>
                <p class="text-muted mb-0">
                    Jawaban yang salah ditampilkan bersama pembahasannya.
                </p>
            </div>

            <div class="card-body">
                <?php $__empty_1 = true; $__currentLoopData = $attempt->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $question = $answer->question;
                        $isCorrect = (bool) $answer->is_correct;
                    ?>

                    <div class="border rounded p-3 mb-4">
                        <div class="d-flex flex-column flex-md-row justify-content-between gap-2 mb-3">
                            <h6 class="fw-bold mb-0">
                                Soal <?php echo e($loop->iteration); ?>

                            </h6>

                            <?php if($isCorrect): ?>
                                <span class="badge bg-label-success">Jawaban Benar</span>
                            <?php else: ?>
                                <span class="badge bg-label-danger">Jawaban Salah</span>
                            <?php endif; ?>
                        </div>

                        <div class="mb-3">
                            <?php echo $question->question ?? 'Soal tidak tersedia.'; ?>

                        </div>

                        <div class="mb-3">
                            <small class="text-muted d-block mb-1">Pilihan Jawaban</small>

                            <?php $__currentLoopData = ($question->options ?? collect()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $selectedOptionId = $answer->selected_option_id
                                        ?? $answer->option_id
                                        ?? null;

                                    $isSelected = $selectedOptionId !== null
                                        && (string) $selectedOptionId === (string) $option->id;

                                    $isAnswerKey = (bool) ($option->is_correct ?? false);
                                ?>

                                <div class="rounded border p-2 mb-2
                                    <?php echo e($isSelected && $isAnswerKey ? 'border-success bg-label-success' : ''); ?>

                                    <?php echo e($isSelected && !$isAnswerKey ? 'border-danger bg-label-danger' : ''); ?>">
                                    <div class="d-flex align-items-start gap-2">
                                        <span>
                                            <?php echo e($option->option_label ?? $option->label ?? ''); ?>

                                        </span>

                                        <div class="flex-grow-1">
                                            <?php echo $option->option_text ?? $option->text ?? ''; ?>

                                        </div>

                                        <?php if($isSelected): ?>
                                            <span class="badge bg-label-primary">Jawaban Anak</span>
                                        <?php endif; ?>

                                        <?php if($isAnswerKey): ?>
                                            <span class="badge bg-label-success">Kunci Jawaban</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <?php if(!$isCorrect && $question && $question->explanation): ?>
                            <div class="alert alert-info mb-0">
                                <h6 class="alert-heading">
                                    <i class="bx bx-bulb me-1"></i>
                                    Pembahasan
                                </h6>
                                <div><?php echo $question->explanation; ?></div>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center py-5">
                        <i class="bx bx-file fs-1 text-muted"></i>
                        <h6 class="mt-2">Belum Ada Detail Jawaban</h6>
                        <p class="text-muted mb-0">
                            Data jawaban untuk percobaan ujian ini belum tersedia.
                        </p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Herd\webapp-ujian\resources\views/results/children-show.blade.php ENDPATH**/ ?>