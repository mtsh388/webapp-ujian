

<?php $__env->startSection('title', 'Import Bank Soal'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-3">

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bx bx-check-circle me-1"></i>
                <?php echo e(session('success')); ?>


                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="alert">
                </button>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bx bx-error-circle me-1"></i>
                <?php echo e(session('error')); ?>


                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="alert">
                </button>
            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">

                <div class="fw-semibold mb-2">
                    Terdapat kesalahan:
                </div>

                <ul class="mb-0 ps-3">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

            </div>
        <?php endif; ?>

        <div class="card border-0 shadow-sm">

            <div class="card-header bg-white border-0 p-4">

                <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-3">

                    <div>
                        <h4 class="mb-1">
                            Import Bank Soal
                        </h4>

                        <p class="text-muted mb-0">
                            Import soal pilihan ganda dan benar/salah dari Microsoft Word.
                        </p>
                    </div>

                    <a
                        href="<?php echo e(route('questions.index')); ?>"
                        class="btn btn-outline-secondary">

                        <i class="bx bx-arrow-back me-1"></i>
                        Kembali

                    </a>

                </div>

            </div>

            <div class="card-body p-4">

                <div class="row g-4">

                    <div class="col-lg-8">

                        <div class="card border-0 bg-light">

                            <div class="card-header bg-transparent border-0 p-4">

                                <h5 class="mb-1">
                                    Import File Word
                                </h5>

                                <p class="text-muted mb-0">
                                    Upload file DOCX untuk membuat bank soal secara otomatis.
                                </p>

                            </div>

                            <div class="card-body p-4">

                                <form
                                    action="<?php echo e(route('questions.import.store')); ?>"
                                    method="POST"
                                    enctype="multipart/form-data">

                                    <?php echo csrf_field(); ?>

                                    <div class="mb-4">

                                        <label
                                            for="subject_id"
                                            class="form-label">

                                            Mata Pelajaran

                                        </label>

                                        <select
                                            name="subject_id"
                                            id="subject_id"
                                            class="form-select <?php $__errorArgs = ['subject_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            required>

                                            <option value="">
                                                Pilih Mata Pelajaran
                                            </option>

                                            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <option
                                                    value="<?php echo e($subject->id); ?>"
                                                    <?php if(old('subject_id') == $subject->id): echo 'selected'; endif; ?>>

                                                    <?php echo e($subject->code); ?> -
                                                    <?php echo e($subject->name); ?>


                                                </option>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>

                                        <?php $__errorArgs = ['subject_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>

                                    <div class="row g-3">

                                        <div class="col-md-6">

                                            <div class="mb-4">

                                                <label
                                                    for="difficulty"
                                                    class="form-label">

                                                    Tingkat Kesulitan

                                                </label>

                                                <select
                                                    name="difficulty"
                                                    id="difficulty"
                                                    class="form-select <?php $__errorArgs = ['difficulty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    required>

                                                    <option value="">
                                                        Pilih Tingkat Kesulitan
                                                    </option>

                                                    <option
                                                        value="easy"
                                                        <?php if(old('difficulty') === 'easy'): echo 'selected'; endif; ?>>
                                                        Mudah
                                                    </option>

                                                    <option
                                                        value="medium"
                                                        <?php if(old('difficulty', 'medium') === 'medium'): echo 'selected'; endif; ?>>
                                                        Sedang
                                                    </option>

                                                    <option
                                                        value="hard"
                                                        <?php if(old('difficulty') === 'hard'): echo 'selected'; endif; ?>>
                                                        Sulit
                                                    </option>

                                                </select>

                                                <?php $__errorArgs = ['difficulty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e($message); ?>

                                                </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                            </div>

                                        </div>

                                        <div class="col-md-6">

                                            <div class="mb-4">

                                                <label
                                                    for="default_score"
                                                    class="form-label">

                                                    Nilai Default

                                                </label>

                                                <input
                                                    type="number"
                                                    name="default_score"
                                                    id="default_score"
                                                    class="form-control <?php $__errorArgs = ['default_score'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    value="<?php echo e(old('default_score', 1)); ?>"
                                                    min="0"
                                                    max="999999.99"
                                                    step="0.01"
                                                    required>

                                                <?php $__errorArgs = ['default_score'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e($message); ?>

                                                </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="mb-4">

                                        <label
                                            for="file"
                                            class="form-label">

                                            File Word

                                        </label>

                                        <input
                                            type="file"
                                            name="file"
                                            id="file"
                                            class="form-control <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            accept=".docx"
                                            required>

                                        <div class="form-text">
                                            Format yang diperbolehkan: DOCX.
                                            Maksimal 10 MB.
                                        </div>

                                        <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>

                                    <div class="border-top pt-4">

                                        <div class="d-flex justify-content-end gap-2">

                                            <a
                                                href="<?php echo e(route('questions.index')); ?>"
                                                class="btn btn-outline-secondary">

                                                Batal

                                            </a>

                                            <button
                                                type="submit"
                                                class="btn btn-primary"
                                                id="btn-import">

                                                <i class="bx bx-upload me-1"></i>
                                                Import Bank Soal

                                            </button>

                                        </div>

                                    </div>

                                </form>

                            </div>

                        </div>

                    </div>

                    <div class="col-lg-4">

                        <div class="card border-0 bg-light mb-4">

                            <div class="card-header bg-transparent border-0 p-4">

                                <h5 class="mb-1">
                                    Format DOCX
                                </h5>

                                <p class="text-muted mb-0">
                                    Gunakan struktur berikut pada file Word.
                                </p>

                            </div>

                            <div class="card-body p-4">

                                <div class="alert alert-primary mb-4">

                                    <div class="fw-semibold mb-2">
                                        Tipe soal ditentukan di DOCX.
                                    </div>

                                    <div>
                                        Tidak perlu memilih jenis soal pada form.
                                    </div>

                                </div>

                                <div class="mb-4">

                                    <div class="fw-semibold mb-2">
                                        Pilihan Ganda
                                    </div>

                                    <pre class="bg-white rounded p-3 mb-0 border"><code>SOAL 1 [PILIHAN_GANDA]

Pertanyaan...

A. Pilihan A
B. Pilihan B
C. Pilihan C
D. Pilihan D

JAWABAN: B

PEMBAHASAN:
Pembahasan...</code></pre>

                                </div>

                                <div class="mb-4">

                                    <div class="fw-semibold mb-2">
                                        Benar / Salah
                                    </div>

                                    <pre class="bg-white rounded p-3 mb-0 border"><code>SOAL 2 [BENAR_SALAH]

Indonesia berada di Asia Tenggara.

JAWABAN: A

PEMBAHASAN:
Pernyataan benar.</code></pre>

                                </div>

                                <div>

                                    <div class="fw-semibold mb-2">
                                        Mixed Type
                                    </div>

                                    <pre class="bg-white rounded p-3 mb-0 border"><code>SOAL 1 [PILIHAN_GANDA]
...

SOAL 2 [BENAR_SALAH]
...

SOAL 3 [PILIHAN_GANDA]
...</code></pre>

                                </div>

                            </div>

                        </div>

                        <div class="card border-0 bg-light">

                            <div class="card-header bg-transparent border-0 p-4">

                                <h5 class="mb-0">
                                    Aturan Import
                                </h5>

                            </div>

                            <div class="card-body p-4">

                                <ul class="mb-0 ps-3">

                                    <li class="mb-2">
                                        Setiap soal wajib memiliki header.
                                    </li>

                                    <li class="mb-2">
                                        Gunakan
                                        <code>[PILIHAN_GANDA]</code>
                                        atau
                                        <code>[BENAR_SALAH]</code>.
                                    </li>

                                    <li class="mb-2">
                                        Pilihan ganda wajib memiliki A-D.
                                    </li>

                                    <li class="mb-2">
                                        Benar/Salah menggunakan A = Benar dan B = Salah.
                                    </li>

                                    <li class="mb-2">
                                        Gambar dapat dimasukkan langsung ke Word.
                                    </li>

                                    <li>
                                        Pembahasan bersifat opsional.
                                    </li>

                                </ul>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const form = document.querySelector(
                'form[action="<?php echo e(route('questions.import.store')); ?>"]'
            );

            const button = document.getElementById('btn-import');

            if (!form || !button) {
                return;
            }

            form.addEventListener('submit', function () {
                button.disabled = true;

                button.innerHTML =
                    '<span class="spinner-border spinner-border-sm me-1"></span>' +
                    'Memproses...';
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Herd\webapp-ujian\resources\views/question-banks/import.blade.php ENDPATH**/ ?>