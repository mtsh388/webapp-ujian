

<?php $__env->startSection('title', 'Kelola Peserta Ujian'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <div class="d-flex align-items-center">
                    <i class="bx bx-check-circle me-2"></i>
                    <div><?php echo e(session('success')); ?></div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <div class="d-flex align-items-center">
                    <i class="bx bx-error-circle me-2"></i>
                    <div><?php echo e(session('error')); ?></div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <div class="d-flex align-items-center">
                    <i class="bx bx-error-circle me-2"></i>
                    <div><?php echo e($errors->first()); ?></div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="card">

            <div class="card-header border-bottom">
                <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-3">

                    <div>
                        <h4 class="card-title mb-1">
                            Kelola Peserta Ujian
                        </h4>

                        <p class="card-subtitle text-muted mb-0">
                            Kelola siswa yang terdaftar, status keaktifan, dan keikutsertaan dalam ujian.
                        </p>
                    </div>

                    <div class="d-flex flex-column flex-sm-row align-items-stretch align-items-sm-center gap-2">

                        <a href="<?php echo e(route('exams.index')); ?>" class="btn btn-label-secondary">
                            <i class="bx bx-arrow-back me-1"></i>
                            Kembali
                        </a>

                        <a href="<?php echo e(route('exams.questions', $exam)); ?>" class="btn btn-label-primary">
                            <i class="bx bx-list-ol me-1"></i>
                            Kelola Soal
                        </a>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('exam.update')): ?>
                            <button
                                type="button"
                                class="btn btn-primary"
                                data-bs-toggle="modal"
                                data-bs-target="#addParticipantModal">
                                <i class="bx bx-user-plus me-1"></i>
                                Tambah Peserta
                            </button>
                        <?php endif; ?>

                    </div>
                </div>
            </div>

            <div class="card-body border-bottom py-3">
                <div class="row g-3 align-items-center">

                    <div class="col-12 col-lg-5">
                        <div class="d-flex align-items-center">
                            <div class="avatar flex-shrink-0 me-3">
                                <span class="avatar-initial rounded bg-label-primary">
                                    <i class="bx bx-notepad"></i>
                                </span>
                            </div>

                            <div class="min-w-0">
                                <small class="text-muted d-block">
                                    Informasi Ujian
                                </small>

                                <span class="fw-semibold d-block text-break">
                                    <?php echo e($exam->title); ?>

                                </span>

                                <small class="text-muted">
                                    Kode: <?php echo e($exam->code); ?>

                                </small>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-lg-3">
                        <div class="d-flex align-items-center">
                            <div class="avatar flex-shrink-0 me-3">
                                <span class="avatar-initial rounded bg-label-info">
                                    <i class="bx bx-book-open"></i>
                                </span>
                            </div>

                            <div>
                                <small class="text-muted d-block">
                                    Mata Pelajaran
                                </small>

                                <span class="fw-semibold">
                                    <?php echo e($exam->subject?->name ?? 'Tanpa Mata Pelajaran'); ?>

                                </span>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-lg-4">
                        <div class="alert alert-label-primary mb-0 py-2 px-3">
                            <div class="d-flex align-items-center">
                                <i class="bx bx-group me-2 fs-4"></i>

                                <div>
                                    <small class="d-block">
                                        Total Peserta Terdaftar
                                    </small>

                                    <span class="fw-semibold">
                                        <?php echo e($participants->count()); ?> peserta
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <div class="card-body border-bottom py-3">
                <div class="row g-3">

                    <div class="col-12 col-md-4">
                        <div class="d-flex align-items-center">
                            <div class="avatar flex-shrink-0 me-3">
                                <span class="avatar-initial rounded bg-label-primary">
                                    <i class="bx bx-group"></i>
                                </span>
                            </div>

                            <div>
                                <small class="text-muted d-block">
                                    Total Peserta
                                </small>

                                <span class="fw-semibold">
                                    <?php echo e($participants->count()); ?> siswa
                                </span>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-md-4">
                        <div class="d-flex align-items-center">
                            <div class="avatar flex-shrink-0 me-3">
                                <span class="avatar-initial rounded bg-label-success">
                                    <i class="bx bx-user-check"></i>
                                </span>
                            </div>

                            <div>
                                <small class="text-muted d-block">
                                    Peserta Aktif
                                </small>

                                <span class="fw-semibold">
                                    <?php echo e($participants->where('is_active', true)->count()); ?> siswa
                                </span>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-md-4">
                        <div class="d-flex align-items-center">
                            <div class="avatar flex-shrink-0 me-3">
                                <span class="avatar-initial rounded bg-label-secondary">
                                    <i class="bx bx-user-x"></i>
                                </span>
                            </div>

                            <div>
                                <small class="text-muted d-block">
                                    Peserta Nonaktif
                                </small>

                                <span class="fw-semibold">
                                    <?php echo e($participants->where('is_active', false)->count()); ?> siswa
                                </span>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <div class="card-header border-bottom">
                <div>
                    <h5 class="card-title mb-1">
                        Daftar Peserta
                    </h5>

                    <p class="card-subtitle text-muted mb-0">
                        Daftar siswa yang telah ditambahkan ke ujian ini.
                    </p>
                </div>
            </div>

            <div class="card-datatable table-responsive">
                <table class="table table-hover border-top">
                    <thead>
                    <tr>
                        <th style="width: 5%">No</th>
                        <th>Siswa</th>
                        <th>Nomor Siswa</th>
                        <th>Kelas</th>
                        <th>Ditambahkan</th>
                        <th>Status</th>
                        <th style="width: 5%">Aksi</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <?php echo e($index + 1); ?>

                            </td>

                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="avatar avatar-sm flex-shrink-0 me-3">
                                            <span class="avatar-initial rounded-circle bg-label-primary">
                                                <?php echo e(strtoupper(substr($participant->student?->full_name ?? 'S', 0, 1))); ?>

                                            </span>
                                    </div>

                                    <div>
                                            <span class="fw-semibold d-block">
                                                <?php echo e($participant->student?->full_name ?? '-'); ?>

                                            </span>

                                        <small class="text-muted">
                                            <?php echo e($participant->student?->user?->email ?? '-'); ?>

                                        </small>
                                    </div>
                                </div>
                            </td>

                            <td>
                                <?php echo e($participant->student?->student_number ?? '-'); ?>

                            </td>

                            <td>
                                <?php echo e($participant->student?->classRoom?->name ?? '-'); ?>

                            </td>

                            <td>
                                <small>
                                    <?php echo e($participant->assigned_at?->format('d M Y H:i') ?? '-'); ?>

                                </small>
                            </td>

                            <td>
                                <?php if($participant->is_active): ?>
                                    <span class="badge bg-label-success">
                                            Aktif
                                        </span>
                                <?php else: ?>
                                    <span class="badge bg-label-secondary">
                                            Nonaktif
                                        </span>
                                <?php endif; ?>
                            </td>

                            <td>
                                <div class="dropdown">
                                    <button
                                        type="button"
                                        class="btn p-0 dropdown-toggle hide-arrow"
                                        data-bs-toggle="dropdown"
                                        aria-expanded="false">
                                        <i class="bx bx-dots-vertical-rounded"></i>
                                    </button>

                                    <div class="dropdown-menu dropdown-menu-end">

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('exam.update')): ?>
                                            <button
                                                type="button"
                                                class="dropdown-item"
                                                onclick="toggleParticipantStatus(
                                                        <?php echo e($exam->id); ?>,
                                                        <?php echo e($participant->id); ?>,
                                                        <?php echo e($participant->is_active ? 'true' : 'false'); ?>

                                                    )">

                                                <?php if($participant->is_active): ?>
                                                    <i class="bx bx-user-x me-1"></i>
                                                    Nonaktifkan
                                                <?php else: ?>
                                                    <i class="bx bx-user-check me-1"></i>
                                                    Aktifkan
                                                <?php endif; ?>
                                            </button>

                                            <button
                                                type="button"
                                                class="dropdown-item text-danger"
                                                onclick="deleteParticipant(
                                                        <?php echo e($exam->id); ?>,
                                                        <?php echo e($participant->id); ?>

                                                    )">
                                                <i class="bx bx-trash me-1"></i>
                                                Hapus
                                            </button>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center py-5">
                                <div class="d-flex flex-column align-items-center">
                                    <div class="avatar mb-3">
                                            <span class="avatar-initial rounded bg-label-secondary">
                                                <i class="bx bx-group fs-3"></i>
                                            </span>
                                    </div>

                                    <h6 class="mb-1">
                                        Belum Ada Peserta
                                    </h6>

                                    <p class="text-muted mb-3">
                                        Belum ada siswa yang ditambahkan ke ujian ini.
                                    </p>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('exam.update')): ?>
                                        <button
                                            type="button"
                                            class="btn btn-primary btn-sm"
                                            data-bs-toggle="modal"
                                            data-bs-target="#addParticipantModal">
                                            <i class="bx bx-user-plus me-1"></i>
                                            Tambah Peserta Sekarang
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>

    <div class="modal fade" id="addParticipantModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">

                <form
                    method="POST"
                    action="<?php echo e(route('exams.participants.store', $exam)); ?>">

                    <?php echo csrf_field(); ?>

                    <div class="modal-header border-bottom">
                        <div>
                            <h5 class="modal-title mb-1">
                                Tambah Peserta Ujian
                            </h5>

                            <small class="text-muted">
                                <?php echo e($exam->title); ?>

                            </small>
                        </div>

                        <button
                            type="button"
                            class="btn-close"
                            data-bs-dismiss="modal"
                            aria-label="Close">
                        </button>
                    </div>

                    <div class="modal-body">

                        <?php if($availableStudents->isEmpty()): ?>
                            <div class="alert alert-label-info mb-0">
                                <div class="d-flex align-items-center">
                                    <i class="bx bx-info-circle me-2"></i>

                                    <span>
                                        Semua siswa aktif sudah menjadi peserta ujian ini.
                                    </span>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="mb-3">
                                <label for="studentSearch" class="form-label">
                                    Cari Siswa
                                </label>

                                <div class="input-group">
                                    <span class="input-group-text">
                                        <i class="bx bx-search"></i>
                                    </span>

                                    <input
                                        type="text"
                                        id="studentSearch"
                                        class="form-control"
                                        placeholder="Cari nama atau nomor siswa...">
                                </div>
                            </div>

                            <div class="border rounded">
                                <div class="p-3 border-bottom">
                                    <div class="form-check">
                                        <input
                                            type="checkbox"
                                            class="form-check-input"
                                            id="selectAllStudents">

                                        <label
                                            class="form-check-label fw-semibold"
                                            for="selectAllStudents">
                                            Pilih Semua Siswa
                                        </label>
                                    </div>
                                </div>

                                <div id="studentList" style="max-height: 400px; overflow-y: auto;">
                                    <?php $__currentLoopData = $availableStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div
                                            class="student-item p-3 border-bottom"
                                            data-search="<?php echo e(strtolower($student->full_name . ' ' . $student->student_number)); ?>">

                                            <div class="form-check">
                                                <input
                                                    type="checkbox"
                                                    class="form-check-input student-checkbox"
                                                    id="student-<?php echo e($student->id); ?>"
                                                    name="student_ids[]"
                                                    value="<?php echo e($student->id); ?>">

                                                <label
                                                    class="form-check-label w-100"
                                                    for="student-<?php echo e($student->id); ?>">

                                                    <span class="fw-semibold d-block">
                                                        <?php echo e($student->full_name); ?>

                                                    </span>

                                                    <small class="text-muted">
                                                        <?php echo e($student->student_number); ?>


                                                        <?php if($student->classRoom): ?>
                                                            · <?php echo e($student->classRoom->name); ?>

                                                        <?php endif; ?>
                                                    </small>
                                                </label>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <div
                                        id="noStudentSearchResult"
                                        class="text-center text-muted py-4 d-none">
                                        Siswa tidak ditemukan.
                                    </div>
                                </div>
                            </div>

                            <div class="mt-3">
                                <small class="text-muted">
                                    <i class="bx bx-check-circle me-1"></i>
                                    <span id="selectedStudentCount">0</span>
                                    siswa dipilih.
                                </small>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="modal-footer border-top">
                        <button
                            type="button"
                            class="btn btn-label-secondary"
                            data-bs-dismiss="modal">
                            Batal
                        </button>

                        <?php if($availableStudents->isNotEmpty()): ?>
                            <button
                                type="submit"
                                class="btn btn-primary"
                                id="submitParticipants"
                                disabled>
                                <i class="bx bx-user-plus me-1"></i>
                                Tambahkan Peserta
                            </button>
                        <?php endif; ?>
                    </div>

                </form>
            </div>
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const studentSearch = document.querySelector('#studentSearch');
            const selectAllStudents = document.querySelector('#selectAllStudents');
            const studentCheckboxes = Array.from(
                document.querySelectorAll('.student-checkbox')
            );
            const selectedStudentCount = document.querySelector('#selectedStudentCount');
            const submitButton = document.querySelector('#submitParticipants');
            const noSearchResult = document.querySelector('#noStudentSearchResult');

            function updateSelection() {
                const checkedCount = studentCheckboxes.filter(
                    checkbox => checkbox.checked
                ).length;

                const visibleCheckboxes = studentCheckboxes.filter(
                    checkbox => checkbox.closest('.student-item').style.display !== 'none'
                );

                if (selectedStudentCount) {
                    selectedStudentCount.textContent = checkedCount;
                }

                if (submitButton) {
                    submitButton.disabled = checkedCount === 0;
                }

                if (selectAllStudents) {
                    selectAllStudents.checked =
                        visibleCheckboxes.length > 0 &&
                        visibleCheckboxes.every(checkbox => checkbox.checked);

                    selectAllStudents.indeterminate =
                        visibleCheckboxes.some(checkbox => checkbox.checked) &&
                        !visibleCheckboxes.every(checkbox => checkbox.checked);
                }
            }

            if (studentSearch) {
                studentSearch.addEventListener('input', function () {
                    const keyword = this.value.toLowerCase().trim();
                    let visibleCount = 0;

                    document.querySelectorAll('.student-item').forEach(function (item) {
                        const searchText = item.dataset.search || '';
                        const isVisible = searchText.includes(keyword);

                        item.style.display = isVisible ? '' : 'none';

                        if (isVisible) {
                            visibleCount++;
                        }
                    });

                    if (noSearchResult) {
                        noSearchResult.classList.toggle(
                            'd-none',
                            visibleCount > 0
                        );
                    }

                    updateSelection();
                });
            }

            if (selectAllStudents) {
                selectAllStudents.addEventListener('change', function () {
                    studentCheckboxes.forEach(function (checkbox) {
                        const item = checkbox.closest('.student-item');

                        if (item && item.style.display !== 'none') {
                            checkbox.checked = selectAllStudents.checked;
                        }
                    });

                    updateSelection();
                });
            }

            studentCheckboxes.forEach(function (checkbox) {
                checkbox.addEventListener('change', updateSelection);
            });

            updateSelection();
        });

        function toggleParticipantStatus(examId, participantId, currentStatus) {
            Swal.fire({
                title: currentStatus ? 'Nonaktifkan Peserta?' : 'Aktifkan Peserta?',
                text: currentStatus
                    ? 'Peserta tidak akan dapat mengikuti ujian ini selama statusnya nonaktif.'
                    : 'Peserta akan diaktifkan kembali untuk ujian ini.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: currentStatus ? 'Ya, Nonaktifkan' : 'Ya, Aktifkan',
                cancelButtonText: 'Batal',
                reverseButtons: true,
                customClass: {
                    confirmButton: currentStatus
                        ? 'btn btn-warning ms-2'
                        : 'btn btn-success ms-2',
                    cancelButton: 'btn btn-label-secondary'
                },
                buttonsStyling: false
            }).then(function (result) {
                if (!result.isConfirmed) {
                    return;
                }

                const csrfToken = document.querySelector('meta[name="csrf-token"]');

                if (!csrfToken) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Gagal',
                        text: 'CSRF token tidak ditemukan.'
                    });

                    return;
                }

                Swal.fire({
                    title: 'Memproses...',
                    text: 'Mohon tunggu sebentar.',
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    showConfirmButton: false,
                    didOpen: function () {
                        Swal.showLoading();
                    }
                });

                fetch(`/ujian/${examId}/peserta/${participantId}/status`, {
                    method: 'PATCH',
                    headers: {
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': csrfToken.getAttribute('content')
                    }
                })
                    .then(async function (response) {
                        const data = await response.json();

                        if (!response.ok) {
                            throw new Error(data.message || 'Gagal mengubah status peserta.');
                        }

                        return data;
                    })
                    .then(function (response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Berhasil',
                            text: response.message || 'Status peserta berhasil diubah.',
                            timer: 1500,
                            showConfirmButton: false
                        }).then(function () {
                            window.location.reload();
                        });
                    })
                    .catch(function (error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Gagal',
                            text: error.message
                        });
                    });
            });
        }

        function deleteParticipant(examId, participantId) {
            Swal.fire({
                title: 'Hapus Peserta?',
                text: 'Peserta akan dihapus dari daftar ujian ini.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ya, Hapus',
                cancelButtonText: 'Batal',
                reverseButtons: true,
                customClass: {
                    confirmButton: 'btn btn-danger ms-2',
                    cancelButton: 'btn btn-label-secondary'
                },
                buttonsStyling: false
            }).then(function (result) {
                if (!result.isConfirmed) {
                    return;
                }

                const csrfToken = document.querySelector('meta[name="csrf-token"]');

                if (!csrfToken) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Gagal',
                        text: 'CSRF token tidak ditemukan.'
                    });

                    return;
                }

                Swal.fire({
                    title: 'Menghapus...',
                    text: 'Mohon tunggu sebentar.',
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    showConfirmButton: false,
                    didOpen: function () {
                        Swal.showLoading();
                    }
                });

                fetch(`/ujian/${examId}/peserta/${participantId}`, {
                    method: 'DELETE',
                    headers: {
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': csrfToken.getAttribute('content')
                    }
                })
                    .then(async function (response) {
                        const data = await response.json();

                        if (!response.ok) {
                            throw new Error(data.message || 'Gagal menghapus peserta.');
                        }

                        return data;
                    })
                    .then(function (response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Berhasil',
                            text: response.message || 'Peserta berhasil dihapus.',
                            timer: 1500,
                            showConfirmButton: false
                        }).then(function () {
                            window.location.reload();
                        });
                    })
                    .catch(function (error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Gagal',
                            text: error.message
                        });
                    });
            });
        }
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Herd\webapp-ujian\resources\views/exams/participants.blade.php ENDPATH**/ ?>