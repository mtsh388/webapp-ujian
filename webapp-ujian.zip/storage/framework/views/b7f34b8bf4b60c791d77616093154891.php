

<?php $__env->startSection('title', 'Dashboard Orang Tua'); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="container-xxl container-p-y">

            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body">
                    <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3">
                        <div>
                            <h4 class="mb-1">
                                Selamat Datang, <?php echo e($parent?->full_name ?? auth()->user()->name); ?>

                            </h4>

                            <p class="text-muted mb-0">
                                Pantau aktivitas dan hasil ujian anak Anda.
                            </p>
                        </div>

                        <span class="badge bg-label-primary px-3 py-2">
                        <i class="icon-base bx bx-home-heart me-1"></i>
                        Orang Tua
                    </span>
                    </div>
                </div>
            </div>

            <div class="row g-4 mb-4">

                <div class="col-sm-6 col-xl-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <span class="fw-medium d-block mb-1">Jumlah Anak</span>
                                    <h3 class="card-title mb-0">
                                        <?php echo e(number_format($children->count(), 0, ',', '.')); ?>

                                    </h3>
                                </div>

                                <div class="avatar">
                                <span class="avatar-initial rounded bg-label-primary">
                                    <i class="icon-base bx bx-group fs-4"></i>
                                </span>
                                </div>
                            </div>

                            <small class="text-muted">
                                Anak yang terhubung
                            </small>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <span class="fw-medium d-block mb-1">Total Ujian</span>
                                    <h3 class="card-title mb-0">
                                        <?php echo e(number_format($totalAttempts, 0, ',', '.')); ?>

                                    </h3>
                                </div>

                                <div class="avatar">
                                <span class="avatar-initial rounded bg-label-info">
                                    <i class="icon-base bx bx-file fs-4"></i>
                                </span>
                                </div>
                            </div>

                            <small class="text-muted">
                                Percobaan ujian seluruh anak
                            </small>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <span class="fw-medium d-block mb-1">Ujian Selesai</span>
                                    <h3 class="card-title mb-0">
                                        <?php echo e(number_format($completedAttempts, 0, ',', '.')); ?>

                                    </h3>
                                </div>

                                <div class="avatar">
                                <span class="avatar-initial rounded bg-label-success">
                                    <i class="icon-base bx bx-check-circle fs-4"></i>
                                </span>
                                </div>
                            </div>

                            <small class="text-muted">
                                Ujian yang telah diselesaikan
                            </small>
                        </div>
                    </div>
                </div>

            </div>

            <div class="row g-4">

                <div class="col-lg-5">
                    <div class="card h-100">
                        <div class="card-header">
                            <h5 class="mb-0">Data Anak</h5>
                        </div>

                        <div class="card-body">

                            <?php $__empty_1 = true; $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="d-flex align-items-center <?php echo e(!$loop->last ? 'mb-4' : ''); ?>">
                                    <div class="avatar me-3">
                                    <span class="avatar-initial rounded bg-label-primary">
                                        <?php echo e(strtoupper(substr($child->full_name, 0, 1))); ?>

                                    </span>
                                    </div>

                                    <div class="flex-grow-1">
                                        <h6 class="mb-1">
                                            <?php echo e($child->full_name); ?>

                                        </h6>

                                        <small class="text-muted d-block">
                                            <?php echo e($child->student_number); ?>

                                        </small>

                                        <small class="text-muted">
                                            Kelas: <?php echo e($child->classRoom?->name ?? '-'); ?>

                                        </small>
                                    </div>

                                    <?php if($child->pivot?->is_primary): ?>
                                        <span class="badge bg-label-success">
                                        Utama
                                    </span>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="text-center py-4">
                                    <div class="mb-3">
                                        <i class="icon-base bx bx-user-x fs-1 text-muted"></i>
                                    </div>

                                    <p class="text-muted mb-0">
                                        Belum ada anak yang terhubung dengan akun ini.
                                    </p>
                                </div>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>

                <div class="col-lg-7">
                    <div class="card h-100">
                        <div class="card-header">
                            <h5 class="mb-0">Hasil Ujian Terbaru</h5>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead>
                                <tr>
                                    <th>Anak</th>
                                    <th>Ujian</th>
                                    <th>Nilai</th>
                                    <th>Status</th>
                                </tr>
                                </thead>

                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $recentAttempts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attempt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <span class="fw-medium">
                                                <?php echo e($attempt->student?->full_name ?? '-'); ?>

                                            </span>
                                        </td>

                                        <td>
                                            <?php echo e($attempt->exam?->title ?? '-'); ?>

                                        </td>

                                        <td>
                                            <?php if($attempt->status === 'submitted'): ?>
                                                <span class="fw-semibold">
                                                    <?php echo e(number_format((float) $attempt->score, 2, ',', '.')); ?>

                                                </span>
                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <?php if($attempt->status === 'submitted'): ?>
                                                <?php if($attempt->passed === true): ?>
                                                    <span class="badge bg-label-success">
                                                        Lulus
                                                    </span>
                                                <?php elseif($attempt->passed === false): ?>
                                                    <span class="badge bg-label-danger">
                                                        Belum Lulus
                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge bg-label-info">
                                                        Selesai
                                                    </span>
                                                <?php endif; ?>
                                            <?php elseif($attempt->status === 'in_progress'): ?>
                                                <span class="badge bg-label-warning">
                                                    Berlangsung
                                                </span>
                                            <?php else: ?>
                                                <span class="badge bg-label-secondary">
                                                    <?php echo e(ucfirst(str_replace('_', ' ', $attempt->status))); ?>

                                                </span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="text-center py-4 text-muted">
                                            Belum ada hasil ujian anak.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Herd\webapp-ujian\resources\views/dashboard/orang-tua.blade.php ENDPATH**/ ?>