<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">

    <div class="app-brand demo">
        <a href="<?php echo e(route('dashboard')); ?>" class="app-brand-link">
            <span class="app-brand-text demo menu-text fw-bold ms-2">
                BIMBEL
            </span>
        </a>

        <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto">
            <i class="icon-base bx bx-chevron-left"></i>
        </a>
    </div>

    <div class="menu-divider mt-0"></div>

    <ul class="menu-inner py-1">

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dashboard.view')): ?>
            <li class="menu-item <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('dashboard')); ?>" class="menu-link">
                    <i class="menu-icon tf-icons bx bx-home"></i>
                    <div>Dashboard</div>
                </a>
            </li>
        <?php endif; ?>

        <?php if(
            auth()->user()->can('class.view') ||
            auth()->user()->can('subject.view') ||
            auth()->user()->can('student.view') ||
            auth()->user()->can('parent.view')
        ): ?>
            <li class="menu-header small text-uppercase">
                <span class="menu-header-text">Master Data</span>
            </li>

            <li class="menu-item
                <?php echo e(request()->routeIs('classes.*') ||
                    request()->routeIs('subjects.*') ||
                    request()->routeIs('students.*') ||
                    request()->routeIs('parents.*')
                        ? 'active open'
                        : ''); ?>">

                <a href="javascript:void(0)" class="menu-link menu-toggle">
                    <i class="menu-icon tf-icons bx bx-data"></i>
                    <div>Master Data</div>
                </a>

                <ul class="menu-sub">

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('class.view')): ?>
                        <li class="menu-item <?php echo e(request()->routeIs('classes.*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('classes.index')); ?>" class="menu-link">
                                <div>Kelas</div>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('subject.view')): ?>
                        <li class="menu-item <?php echo e(request()->routeIs('subjects.*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('subjects.index')); ?>" class="menu-link">
                                <div>Mata Pelajaran</div>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('student.view')): ?>
                        <li class="menu-item <?php echo e(request()->routeIs('students.*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('students.index')); ?>" class="menu-link">
                                <div>Siswa</div>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('parent.view')): ?>
                        <li class="menu-item <?php echo e(request()->routeIs('parents.*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('parents.index')); ?>" class="menu-link">
                                <div>Orang Tua</div>
                            </a>
                        </li>
                    <?php endif; ?>

                </ul>
            </li>
        <?php endif; ?>

        <?php if(
            auth()->user()->can('question.view') ||
            auth()->user()->can('question.create') ||
            auth()->user()->can('question.update') ||
            auth()->user()->can('question.delete')
        ): ?>
            <li class="menu-header small text-uppercase">
                <span class="menu-header-text">Bank Soal</span>
            </li>

            <li class="menu-item <?php echo e(request()->routeIs('questions.*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('questions.index')); ?>" class="menu-link">
                    <i class="menu-icon tf-icons bx bx-book-open"></i>
                    <div>Bank Soal</div>
                </a>
            </li>
        <?php endif; ?>

        <?php if(
            auth()->user()->can('exam.view') ||
            auth()->user()->can('exam.create') ||
            auth()->user()->can('exam.update') ||
            auth()->user()->can('exam.delete') ||
            auth()->user()->can('exam.take')
        ): ?>
            <li class="menu-header small text-uppercase">
                <span class="menu-header-text">Ujian</span>
            </li>

            <li class="menu-item <?php echo e(request()->routeIs('exams.*') ? 'active open' : ''); ?>">

                <a href="javascript:void(0)" class="menu-link menu-toggle">
                    <i class="menu-icon tf-icons bx bx-edit"></i>
                    <div>Ujian</div>
                </a>

                <ul class="menu-sub">

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('exam.view')): ?>
                        <li class="menu-item <?php echo e(request()->routeIs('exams.index') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('exams.index')); ?>" class="menu-link">
                                <div>Daftar Ujian</div>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('exam.create')): ?>
                        <li class="menu-item <?php echo e(request()->routeIs('exams.create') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('exams.create')); ?>" class="menu-link">
                                <div>Buat Ujian</div>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('exam.take')): ?>
                        <li class="menu-item <?php echo e(request()->routeIs('exams.available') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('exams.available')); ?>" class="menu-link">
                                <div>Ujian Saya</div>
                            </a>
                        </li>
                    <?php endif; ?>

                </ul>
            </li>
        <?php endif; ?>

        <?php if(
            auth()->user()->can('result.view') ||
            auth()->user()->can('result.view_own') ||
            auth()->user()->can('result.view_child')
        ): ?>
            <li class="menu-header small text-uppercase">
                <span class="menu-header-text">Hasil Ujian</span>
            </li>

            <li class="menu-item <?php echo e(request()->routeIs('results.*') ? 'active' : ''); ?>">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('result.view')): ?>
                    <a href="<?php echo e(route('results.index')); ?>" class="menu-link">
                        <i class="menu-icon tf-icons bx bx-bar-chart-alt-2"></i>
                        <div>Hasil Ujian</div>
                    </a>
                <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('result.view_own')): ?>
                    <a href="<?php echo e(route('results.my')); ?>" class="menu-link">
                        <i class="menu-icon tf-icons bx bx-bar-chart-alt-2"></i>
                        <div>Hasil Saya</div>
                    </a>
                <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('result.view_child')): ?>
                    <a href="<?php echo e(route('results.children')); ?>" class="menu-link">
                        <i class="menu-icon tf-icons bx bx-bar-chart-alt-2"></i>
                        <div>Hasil Anak</div>
                    </a>
                <?php endif; ?>
            </li>
        <?php endif; ?>

        <li class="menu-header small text-uppercase">
            <span class="menu-header-text">Akun</span>
        </li>

        <li class="menu-item <?php echo e(request()->routeIs('profile') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('profile')); ?>" class="menu-link">
                <i class="menu-icon tf-icons bx bx-user"></i>
                <div>Profil Saya</div>
            </a>
        </li>
        <li class="menu-item">
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>

                <button type="submit"
                        class="menu-link border-0 bg-transparent w-100 text-start">
                    <i class="menu-icon tf-icons bx bx-log-out"></i>
                    <div>Logout</div>
                </button>
            </form>
        </li>

    </ul>
</aside>
<?php /**PATH C:\Herd\webapp-ujian\resources\views/template/sidebar.blade.php ENDPATH**/ ?>