

<?php $__env->startSection('title', 'Detail Orang Tua'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-3">

        <div class="card border-0 shadow-sm rounded-4">

            <div class="card-header bg-white border-0 p-4">
                <div class="d-flex justify-content-between align-items-center">

                    <div>
                        <h4 class="mb-1 fw-semibold">
                            <i class="bx bx-user me-2"></i>
                            Detail Orang Tua
                        </h4>

                        <p class="text-muted mb-0">
                            Informasi orang tua dan siswa yang terhubung.
                        </p>
                    </div>

                    <div class="d-flex gap-2">

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('parent.update')): ?>
                            <a
                                href="<?php echo e(route('parents.edit', $parent)); ?>"
                                class="btn btn-primary"
                            >
                                <i class="bx bx-edit me-1"></i>
                                Edit
                            </a>
                        <?php endif; ?>

                        <a
                            href="<?php echo e(route('parents.index')); ?>"
                            class="btn btn-light border"
                        >
                            Kembali
                        </a>

                    </div>

                </div>
            </div>

            <div class="card-body p-4">

                <div class="row g-4">

                    <div class="col-md-6">

                        <div class="card border shadow-none h-100">
                            <div class="card-header bg-transparent">
                                <h6 class="mb-0 fw-semibold">
                                    Informasi Orang Tua
                                </h6>
                            </div>

                            <div class="card-body">

                                <div class="mb-3">
                                    <div class="text-muted small">
                                        Nama Lengkap
                                    </div>

                                    <div class="fw-semibold">
                                        <?php echo e($parent->full_name); ?>

                                    </div>
                                </div>

                                <div class="mb-3">
                                    <div class="text-muted small">
                                        No. Telepon
                                    </div>

                                    <div>
                                        <?php echo e($parent->phone ?: '-'); ?>

                                    </div>
                                </div>

                                <div class="mb-3">
                                    <div class="text-muted small">
                                        Alamat
                                    </div>

                                    <div>
                                        <?php echo e($parent->address ?: '-'); ?>

                                    </div>
                                </div>

                                <div>
                                    <div class="text-muted small mb-1">
                                        Status
                                    </div>

                                    <?php if($parent->is_active): ?>
                                        <span class="badge bg-label-success">
                                            Aktif
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-label-secondary">
                                            Tidak Aktif
                                        </span>
                                    <?php endif; ?>
                                </div>

                            </div>
                        </div>

                    </div>

                    <div class="col-md-6">

                        <div class="card border shadow-none h-100">
                            <div class="card-header bg-transparent">
                                <h6 class="mb-0 fw-semibold">
                                    Siswa
                                </h6>
                            </div>

                            <div class="card-body">

                                <?php $__empty_1 = true; $__currentLoopData = $parent->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="d-flex align-items-center mb-3">

                                        <div class="avatar me-3">
                                            <span class="avatar-initial rounded bg-label-primary">
                                                <i class="bx bx-user"></i>
                                            </span>
                                        </div>

                                        <div>
                                            <div class="fw-semibold">
                                                <?php echo e($student->full_name); ?>

                                            </div>

                                            <div class="text-muted small">
                                                <?php echo e($student->student_number); ?>

                                                <?php if($student->classRoom): ?>
                                                    · <?php echo e($student->classRoom->name); ?>

                                                <?php endif; ?>
                                            </div>

                                            <?php if($student->pivot->relationship): ?>
                                                <div class="text-muted small">
                                                    <?php echo e($student->pivot->relationship); ?>


                                                    <?php if($student->pivot->is_primary): ?>
                                                        · Utama
                                                    <?php endif; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="text-muted">
                                        Belum ada siswa yang terhubung.
                                    </div>
                                <?php endif; ?>

                            </div>
                        </div>

                    </div>

                </div>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Herd\webapp-ujian\resources\views/parents/show.blade.php ENDPATH**/ ?>