

<?php $__env->startSection('title', 'Dashboard Siswa'); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="container-xxl container-p-y">

            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body">
                    <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3">
                        <div>
                            <h4 class="mb-1">
                                Selamat Datang, <?php echo e($student?->full_name ?? auth()->user()->name); ?>

                            </h4>

                            <p class="text-muted mb-0">
                                Silakan pilih ujian yang tersedia dan lihat hasil ujian Anda.
                            </p>
                        </div>

                        <span class="badge bg-label-primary px-3 py-2">
                        <i class="icon-base bx bx-user me-1"></i>
                        Siswa
                    </span>
                    </div>
                </div>
            </div>

            <div class="row g-4 mb-4">

                <div class="col-sm-6 col-xl-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <span class="fw-medium d-block mb-1">Ujian Tersedia</span>
                                    <h3 class="card-title mb-0">
                                        <?php echo e(number_format($availableExams, 0, ',', '.')); ?>

                                    </h3>
                                </div>

                                <div class="avatar">
                                <span class="avatar-initial rounded bg-label-primary">
                                    <i class="icon-base bx bx-file fs-4"></i>
                                </span>
                                </div>
                            </div>

                            <small class="text-muted">
                                Ujian yang sedang tersedia
                            </small>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <span class="fw-medium d-block mb-1">Total Percobaan</span>
                                    <h3 class="card-title mb-0">
                                        <?php echo e(number_format($totalAttempts, 0, ',', '.')); ?>

                                    </h3>
                                </div>

                                <div class="avatar">
                                <span class="avatar-initial rounded bg-label-info">
                                    <i class="icon-base bx bx-history fs-4"></i>
                                </span>
                                </div>
                            </div>

                            <small class="text-muted">
                                Seluruh percobaan ujian
                            </small>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <span class="fw-medium d-block mb-1">Ujian Selesai</span>
                                    <h3 class="card-title mb-0">
                                        <?php echo e(number_format($completedAttempts, 0, ',', '.')); ?>

                                    </h3>
                                </div>

                                <div class="avatar">
                                <span class="avatar-initial rounded bg-label-success">
                                    <i class="icon-base bx bx-check-circle fs-4"></i>
                                </span>
                                </div>
                            </div>

                            <small class="text-muted">
                                Ujian yang telah dikumpulkan
                            </small>
                        </div>
                    </div>
                </div>

            </div>

            <div class="row g-4">

                <div class="col-lg-8">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Riwayat Ujian Terbaru</h5>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead>
                                <tr>
                                    <th>Ujian</th>
                                    <th>Status</th>
                                    <th>Nilai</th>
                                    <th>Tanggal</th>
                                </tr>
                                </thead>

                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $recentAttempts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attempt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <span class="fw-medium">
                                                <?php echo e($attempt->exam?->title ?? '-'); ?>

                                            </span>
                                        </td>

                                        <td>
                                            <?php if($attempt->status === 'submitted'): ?>
                                                <span class="badge bg-label-success">Selesai</span>
                                            <?php elseif($attempt->status === 'in_progress'): ?>
                                                <span class="badge bg-label-warning">Sedang Dikerjakan</span>
                                            <?php elseif($attempt->status === 'expired'): ?>
                                                <span class="badge bg-label-danger">Expired</span>
                                            <?php else: ?>
                                                <span class="badge bg-label-secondary">
                                                    <?php echo e(ucfirst(str_replace('_', ' ', $attempt->status))); ?>

                                                </span>
                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <?php if($attempt->status === 'submitted'): ?>
                                                <span class="fw-semibold">
                                                    <?php echo e(number_format((float) $attempt->score, 2, ',', '.')); ?>

                                                </span>
                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <?php echo e($attempt->submitted_at?->format('d M Y H:i') ?? '-'); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="text-center py-4 text-muted">
                                            Belum ada riwayat ujian.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="card h-100">
                        <div class="card-header">
                            <h5 class="mb-0">Informasi Siswa</h5>
                        </div>

                        <div class="card-body">

                            <div class="mb-4">
                                <small class="text-muted d-block mb-1">
                                    Nama
                                </small>

                                <span class="fw-semibold">
                                <?php echo e($student?->full_name ?? auth()->user()->name); ?>

                            </span>
                            </div>

                            <div class="mb-4">
                                <small class="text-muted d-block mb-1">
                                    Nomor Siswa
                                </small>

                                <span class="fw-semibold">
                                <?php echo e($student?->student_number ?? '-'); ?>

                            </span>
                            </div>

                            <div class="mb-4">
                                <small class="text-muted d-block mb-1">
                                    Kelas
                                </small>

                                <span class="fw-semibold">
                                <?php echo e($student?->classRoom?->name ?? '-'); ?>

                            </span>
                            </div>

                            <div>
                                <small class="text-muted d-block mb-1">
                                    Status
                                </small>

                                <?php if($student?->is_active): ?>
                                    <span class="badge bg-label-success">Aktif</span>
                                <?php else: ?>
                                    <span class="badge bg-label-secondary">Tidak Aktif</span>
                                <?php endif; ?>
                            </div>

                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Herd\webapp-ujian\resources\views/dashboard/siswa.blade.php ENDPATH**/ ?>