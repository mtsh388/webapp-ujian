

<?php $__env->startSection('title', 'Hasil Ujian Saya'); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('results._detail', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Herd\webapp-ujian\resources\views/results/my-show.blade.php ENDPATH**/ ?>