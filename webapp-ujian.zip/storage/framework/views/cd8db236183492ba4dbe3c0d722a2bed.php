

<?php $__env->startSection('title', 'Edit Ujian'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <div class="d-flex align-items-center">
                    <i class="bx bx-check-circle me-2"></i>
                    <div><?php echo e(session('success')); ?></div>
                </div>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <div class="d-flex align-items-center">
                    <i class="bx bx-error-circle me-2"></i>
                    <div><?php echo e(session('error')); ?></div>
                </div>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <div class="d-flex align-items-start">
                    <i class="bx bx-error-circle me-2 fs-4"></i>

                    <div>
                        <h6 class="alert-heading mb-1">Periksa kembali formulir Anda</h6>

                        <ul class="mb-0 ps-3">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('exams.update', $exam)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="card">

                <div class="card-header border-bottom">
                    <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-3">

                        <div>
                            <h4 class="card-title mb-1">
                                Edit Ujian
                            </h4>

                            <p class="card-subtitle text-muted mb-0">
                                Perbarui informasi, jadwal, status, dan konfigurasi ujian.
                            </p>
                        </div>

                        <div class="d-flex flex-column flex-sm-row align-items-stretch align-items-sm-center gap-2">

                            <a href="<?php echo e(route('exams.index')); ?>" class="btn btn-outline-secondary">
                                <i class="bx bx-arrow-back me-1"></i>
                                Kembali
                            </a>

                            <a href="<?php echo e(route('exams.questions', $exam)); ?>" class="btn btn-outline-primary">
                                <i class="bx bx-list-check me-1"></i>
                                Kelola Soal
                            </a>

                        </div>
                    </div>
                </div>

                <div class="card-body border-bottom py-3">
                    <div class="row g-3">

                        <div class="col-12 col-md-4">
                            <div class="d-flex align-items-center">
                                <div class="avatar flex-shrink-0 me-3">
                                    <span class="avatar-initial rounded bg-label-primary">
                                        <i class="bx bx-notepad"></i>
                                    </span>
                                </div>

                                <div>
                                    <small class="text-muted d-block">
                                        ID Ujian
                                    </small>

                                    <span class="fw-semibold">
                                        #<?php echo e($exam->id); ?>

                                    </span>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-md-8">
                            <div class="alert alert-label-primary mb-0 py-2 px-3">
                                <div class="d-flex align-items-center">
                                    <i class="bx bx-info-circle me-2"></i>

                                    <small>
                                        Periksa kembali konfigurasi ujian sebelum menyimpan perubahan.
                                    </small>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="card-header border-bottom">
                    <h5 class="mb-1">Informasi Ujian</h5>

                    <p class="text-muted mb-0">
                        Atur mata pelajaran, judul, dan petunjuk pengerjaan ujian.
                    </p>
                </div>

                <div class="card-body pt-4">
                    <div class="row">

                        <div class="col-md-6 mb-3">
                            <label for="subject_id" class="form-label">
                                Mata Pelajaran <span class="text-danger">*</span>
                            </label>

                            <select
                                class="form-select <?php $__errorArgs = ['subject_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="subject_id"
                                name="subject_id"
                                required
                            >
                                <option value="">-- Pilih Mata Pelajaran --</option>

                                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($subject->id); ?>"
                                        <?php echo e(old('subject_id', $exam->subject_id) == $subject->id ? 'selected' : ''); ?>

                                    >
                                        <?php echo e($subject->name); ?> (<?php echo e($subject->code); ?>)
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <?php $__errorArgs = ['subject_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="title" class="form-label">
                                Judul Ujian <span class="text-danger">*</span>
                            </label>

                            <input
                                type="text"
                                class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="title"
                                name="title"
                                value="<?php echo e(old('title', $exam->title)); ?>"
                                placeholder="Contoh: Ujian Tengah Semester"
                                maxlength="255"
                                required
                            >

                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-12 mb-3">
                            <label for="description" class="form-label">
                                Deskripsi / Petunjuk
                            </label>

                            <textarea
                                class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="description"
                                name="description"
                                rows="3"
                                placeholder="Masukkan petunjuk ujian..."
                            ><?php echo e(old('description', $exam->description)); ?></textarea>

                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>
                </div>

                <div class="card-header border-top border-bottom">
                    <h5 class="mb-1">Pengaturan Penilaian</h5>

                    <p class="text-muted mb-0">
                        Tentukan durasi, nilai kelulusan, dan batas percobaan peserta.
                    </p>
                </div>

                <div class="card-body pt-4">
                    <div class="row">

                        <div class="col-md-4 mb-3">
                            <label for="duration_minutes" class="form-label">
                                Durasi (Menit) <span class="text-danger">*</span>
                            </label>

                            <input
                                type="number"
                                class="form-control <?php $__errorArgs = ['duration_minutes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="duration_minutes"
                                name="duration_minutes"
                                value="<?php echo e(old('duration_minutes', $exam->duration_minutes)); ?>"
                                min="1"
                                required
                            >

                            <?php $__errorArgs = ['duration_minutes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-md-4 mb-3">
                            <label for="passing_score" class="form-label">
                                Nilai KKM / Lulus <span class="text-danger">*</span>
                            </label>

                            <input
                                type="number"
                                step="0.01"
                                class="form-control <?php $__errorArgs = ['passing_score'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="passing_score"
                                name="passing_score"
                                value="<?php echo e(old('passing_score', $exam->passing_score)); ?>"
                                min="0"
                                max="100"
                                required
                            >

                            <?php $__errorArgs = ['passing_score'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-md-4 mb-3">
                            <label for="max_attempts" class="form-label">
                                Batas Percobaan <span class="text-danger">*</span>
                            </label>

                            <input
                                type="number"
                                class="form-control <?php $__errorArgs = ['max_attempts'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="max_attempts"
                                name="max_attempts"
                                value="<?php echo e(old('max_attempts', $exam->max_attempts)); ?>"
                                min="1"
                                required
                            >

                            <?php $__errorArgs = ['max_attempts'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>
                </div>

                <div class="card-header border-top border-bottom">
                    <h5 class="mb-1">Jadwal Pelaksanaan</h5>

                    <p class="text-muted mb-0">
                        Tentukan kapan ujian dimulai dan kapan ujian berakhir.
                    </p>
                </div>

                <div class="card-body pt-4">
                    <div class="row">

                        <div class="col-md-6 mb-3">
                            <label for="start_at" class="form-label">
                                Waktu Mulai <span class="text-danger">*</span>
                            </label>

                            <input
                                type="datetime-local"
                                class="form-control <?php $__errorArgs = ['start_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="start_at"
                                name="start_at"
                                value="<?php echo e(old('start_at', $exam->start_at ? $exam->start_at->format('Y-m-d\TH:i') : '')); ?>"
                                required
                            >

                            <?php $__errorArgs = ['start_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="end_at" class="form-label">
                                Waktu Berakhir <span class="text-danger">*</span>
                            </label>

                            <input
                                type="datetime-local"
                                class="form-control <?php $__errorArgs = ['end_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="end_at"
                                name="end_at"
                                value="<?php echo e(old('end_at', $exam->end_at ? $exam->end_at->format('Y-m-d\TH:i') : '')); ?>"
                                required
                            >

                            <?php $__errorArgs = ['end_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-12">
                            <div class="alert alert-label-info mb-0" role="alert">
                                <div class="d-flex align-items-center">
                                    <i class="bx bx-info-circle me-2"></i>

                                    <small>
                                        Pastikan waktu berakhir lebih lambat daripada waktu mulai.
                                    </small>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="card-header border-top border-bottom">
                    <h5 class="mb-1">Status dan Opsi Ujian</h5>

                    <p class="text-muted mb-0">
                        Atur publikasi ujian, pengacakan soal, dan penampilan hasil.
                    </p>
                </div>

                <div class="card-body pt-4">

                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <label for="status" class="form-label">
                                Status Ujian
                            </label>

                            <select
                                class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="status"
                                name="status"
                            >
                                <option
                                    value="draft"
                                    <?php echo e(old('status', $exam->status) == 'draft' ? 'selected' : ''); ?>

                                >
                                    Draft
                                </option>

                                <option
                                    value="published"
                                    <?php echo e(old('status', $exam->status) == 'published' ? 'selected' : ''); ?>

                                >
                                    Published
                                </option>

                                <option
                                    value="closed"
                                    <?php echo e(old('status', $exam->status) == 'closed' ? 'selected' : ''); ?>

                                >
                                    Closed
                                </option>
                            </select>

                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div class="form-text">
                                Pastikan kesiapan soal dan peserta sebelum menerbitkan ujian.
                            </div>
                        </div>
                    </div>

                    <div class="row g-3">

                        <div class="col-md-6">
                            <div class="border rounded p-3 h-100">
                                <div class="form-check form-switch">
                                    <input
                                        class="form-check-input"
                                        type="checkbox"
                                        id="shuffle_questions"
                                        name="shuffle_questions"
                                        value="1"
                                        <?php echo e(old('shuffle_questions', $exam->shuffle_questions) ? 'checked' : ''); ?>

                                    >

                                    <label class="form-check-label fw-semibold" for="shuffle_questions">
                                        Acak Urutan Soal
                                    </label>
                                </div>

                                <p class="text-muted small mb-0 mt-2">
                                    Mengacak urutan soal yang diterima peserta.
                                </p>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="border rounded p-3 h-100">
                                <div class="form-check form-switch">
                                    <input
                                        class="form-check-input"
                                        type="checkbox"
                                        id="shuffle_options"
                                        name="shuffle_options"
                                        value="1"
                                        <?php echo e(old('shuffle_options', $exam->shuffle_options) ? 'checked' : ''); ?>

                                    >

                                    <label class="form-check-label fw-semibold" for="shuffle_options">
                                        Acak Pilihan Jawaban
                                    </label>
                                </div>

                                <p class="text-muted small mb-0 mt-2">
                                    Mengacak urutan pilihan jawaban pada soal.
                                </p>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="border rounded p-3 h-100">
                                <div class="form-check form-switch">
                                    <input
                                        class="form-check-input"
                                        type="checkbox"
                                        id="show_result_immediately"
                                        name="show_result_immediately"
                                        value="1"
                                        <?php echo e(old('show_result_immediately', $exam->show_result_immediately) ? 'checked' : ''); ?>

                                    >

                                    <label class="form-check-label fw-semibold" for="show_result_immediately">
                                        Tampilkan Nilai Langsung
                                    </label>
                                </div>

                                <p class="text-muted small mb-0 mt-2">
                                    Mengizinkan peserta melihat nilai setelah menyelesaikan ujian.
                                </p>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="border rounded p-3 h-100">
                                <div class="form-check form-switch">
                                    <input
                                        class="form-check-input"
                                        type="checkbox"
                                        id="show_correct_answers"
                                        name="show_correct_answers"
                                        value="1"
                                        <?php echo e(old('show_correct_answers', $exam->show_correct_answers) ? 'checked' : ''); ?>

                                    >

                                    <label class="form-check-label fw-semibold" for="show_correct_answers">
                                        Tampilkan Kunci Jawaban
                                    </label>
                                </div>

                                <p class="text-muted small mb-0 mt-2">
                                    Mengizinkan peserta melihat jawaban benar setelah ujian selesai.
                                </p>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="card-footer border-top">
                    <div class="d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-2">

                        <a href="<?php echo e(route('exams.index')); ?>" class="btn btn-outline-secondary mt-3">
                            <i class="bx bx-x me-1"></i>
                            Batal
                        </a>

                        <button type="submit" class="btn btn-primary mt-3">
                            <i class="bx bx-save me-1"></i>
                            Update Ujian
                        </button>

                    </div>
                </div>

            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Herd\webapp-ujian\resources\views/exams/edit.blade.php ENDPATH**/ ?>